function submitForm() {
	document.getElementById("sub").textContent = "This doesn't actually work!";
	document.getElementById('sub').disabled = 'disabled';
}
